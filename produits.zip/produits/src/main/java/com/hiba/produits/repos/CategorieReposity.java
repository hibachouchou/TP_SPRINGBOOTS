package com.hiba.produits.repos;



import org.springframework.data.jpa.repository.JpaRepository;

import com.hiba.produits.entities.Categorie;

public interface CategorieReposity  extends JpaRepository<Categorie, Long> {

	


}